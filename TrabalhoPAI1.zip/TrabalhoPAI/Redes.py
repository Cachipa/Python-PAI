import numpy
import pandas as pd
import os
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import numpy as np
import cv2
import random
import cv2
import os
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, pair_confusion_matrix
from sklearn.preprocessing import LabelEncoder
import sklearn.metrics 
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.metrics import classification_report
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import History
from tensorflow.keras.layers import Conv2D
from tensorflow.python.client import device_lib
from tensorflow.keras.layers import GlobalAveragePooling2D

# Load your data from CSV
df = pd.read_csv('caracteristicas_imagens.csv')

# Function to load and preprocess images
def load_and_preprocess_images(folder_path, filenames):
    images = []
    for filename in filenames:
        image_path = os.path.join(folder_path, filename)
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        images.append(image)
    return np.array(images)

# Function to load and preprocess images
def load_and_preprocess_images(df):
    images = []
    for index, row in df.iterrows():
        image_path = f"{row['Pasta']}/{row['Nome da Imagem']}"
        print(image_path)
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        images.append(image)
    return np.array(images)

# Load images from their respective folders
images = load_and_preprocess_images(df)
X_images = np.array(images)


X_images_flat = X_images.reshape(X_images.shape[0], -1)

X_numerical = df[['Área', 'Compacidade', 'Excentricidade']].values
X_combined = np.concatenate([X_images_flat, X_numerical], axis=1)

label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['Pasta'])
ybi = np.where(df['Pasta'] == 'Negative', 0, 1)

# Treino e teste dados
X_trainbi, X_testbi, y_trainbi, y_testbi = train_test_split(X_images, ybi, test_size=0.2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(X_images, y, test_size=0.2, random_state=42)

# Cria Modelo
def create_resnet_model(num_classes):
    base_model = ResNet50(weights='imagenet', include_top=False, input_shape=(100, 100, 3))
    model = Sequential([
        base_model,
        GlobalAveragePooling2D(),
        Dense(512, activation='relu'),
        Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer=Adam(), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

# Treinar o modelo binario
def train_and_evaluate_modelbi(model, X_trainbi, X_testbi, y_trainbi, y_testbi, num_epochs=1):
    history = model.fit(X_trainbi, y_trainbi, epochs=num_epochs, validation_data=(X_testbi, y_testbi))
    print("Binario matriz de confusao:")
    matrizbi = confusion_matrix(y_testbi, predicted_classes)
    print(matrizbi)
    return history

# Treinar o modelo multi
def train_and_evaluate_model(model, X_train, y_train, X_test, y_test, num_epochs=1):
    history = model.fit(X_train, y_train, epochs=num_epochs, validation_data=(X_test, y_test))
    print("Multi matriz de confusao:")
    matriz = confusion_matrix(y_test, predicted_classes2)
    print(matriz)
    return history

# Modelo binary
binary_model = create_resnet_model(2)
prever = binary_model.predict(X_testbi)
predicted_classes = np.argmax(prever, axis=1)
print(predicted_classes)
binary_history = train_and_evaluate_modelbi(binary_model, X_trainbi, X_testbi, y_trainbi, y_testbi)

# Modelo multi-class 
multi_model = create_resnet_model(6)
prever2 = multi_model.predict(X_test)
predicted_classes2 = np.argmax(prever2, axis=1)
print(predicted_classes2)
multi_history = train_and_evaluate_model(multi_model, X_train, y_train, X_test, y_test)


# Compare resultados
print("\nResNet Binary Accuracy:", binary_history.history['val_accuracy'][-1])

print("\nResNet Multi-Class Accuracy:", multi_history.history['val_accuracy'][-1])


plt.plot(binary_history.history['accuracy'], label='Binary Training Accuracy')
plt.plot(binary_history.history['val_accuracy'], label='Binary Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Loss/Accuracy')
plt.title('Binary Model Learning Curve')
plt.legend()
plt.savefig('Binary.png')


plt.plot(multi_history.history['accuracy'], label='Multi Training Accuracy')
plt.plot(multi_history.history['val_accuracy'], label='Multi Validation Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Loss/Accuracy')
plt.title('Multi Model Learning Curve')
plt.legend()
plt.savefig('Multi.png')
