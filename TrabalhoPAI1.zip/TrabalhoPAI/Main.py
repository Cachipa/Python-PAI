import pandas as pd
import os
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import numpy as np
import cv2

# Rode esse apenas depois de ter rodado o Run.py !!!!!!!!


dataFrame = pd.read_csv("classifications.csv")
unique_folders = dataFrame['bethesda_system'].unique()

selected_folder = ""  # Variável para armazenar a pasta selecionada

# Carrega a lista de imagens da pasta selecionada
def load_images():
    images_list.delete(0, tk.END)
    for filename in os.listdir("Imagens"):
      images_list.insert(tk.END, filename)


def load_image(event):
    if images_list.curselection():
        selected_image = images_list.get(images_list.curselection())
        img_path2 = os.path.join("Segmentado", selected_image)
        img_path = os.path.join("Imagens", selected_image)

        # Carrega a imagem original
        original_img = Image.open(img_path2)
        #original_img = Image.open(img_path) # Imagem original nao segmentada
        original_img = original_img.resize((500, 500))
        original_img = ImageTk.PhotoImage(original_img)

        # Exibe a imagem original
        label.config(image=original_img)
        label.image = original_img

        # Carrega e segmenta a imagem
        segmented_img = segment2_image(img_path)
        segmented_img = Image.fromarray(segmented_img)
        segmented_img = segmented_img.resize((500, 500))
        segmented_img = ImageTk.PhotoImage(segmented_img)

        # Exibe a imagem segmentada ao lado da original
        segmented_label.config(image=segmented_img)
        segmented_label.image = segmented_img

def segment2_image(img_path):
    # Carrega a imagem usando OpenCV
    imagem = cv2.imread(img_path)

    # Converter para escala de cinza (se necessário)
    imagem_cinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(imagem_cinza, (5, 5), 0)

    # Aplicar limiarização
    _, imagem_limiarizada2 = cv2.threshold(imagem_cinza, 120, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5,5),np.uint8)
    eroded_image = cv2.erode(imagem_limiarizada2, kernel, iterations=1)
    imagem_limiarizada = cv2.adaptiveThreshold(eroded_image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

    # Converter a imagem original para uma imagem de calor
    imagem_calor = cv2.applyColorMap(blurred , cv2.COLORMAP_JET)
    imagem_cinza2 = cv2.cvtColor(imagem_calor, cv2.COLOR_BGR2GRAY)
    _, imagem_limiarizada3 = cv2.threshold(imagem_cinza2, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    imagem_limiarizada4 = cv2.adaptiveThreshold(imagem_limiarizada3, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

    # Encontrar contornos na imagem limiarizada
    contornos, hierarchy = cv2.findContours(imagem_limiarizada3, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    min_size = 2000
    filtered_contours = []
    for contour in contornos:
        area = cv2.contourArea(contour)
        if area > min_size:
            filtered_contours.append(contour)
    contornada = cv2.drawContours(imagem.copy(), filtered_contours, -1, 255, 3)


    def detect_large_contours(contours, threshold=1000):
        large_contours = []
        for contour in contours:
            if cv2.contourArea(contour) > threshold:
                M = cv2.moments(contour)
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
                large_contours.append((cX, cY))
        return large_contours

    large_contours = detect_large_contours(filtered_contours)
    for (cX, cY) in large_contours:
        cv2.rectangle(contornada,(cX,cY),(cX+100,cY+100),(0,255,0),5)
    # Iterar sobre os contornos e recortar as regiões ao redor dos núcleos

    return contornada

def grafico ():
    # Carregue o CSV gerado pelo código anterior
    df = pd.read_csv('caracteristicas_imagens.csv')

    # Crie um gráfico de dispersão com diferentes cores para cada pasta
    plt.figure(figsize=(10, 6))

    for pasta in df['Pasta'].unique():
        pasta_data = df[df['Pasta'] == pasta]

        # Define a cor preta para "Negative for intraepithelial lesion"
        cor = 'black' if pasta == 'Negative for intraepithelial lesion' else None
        
        plt.scatter(pasta_data['Área'], pasta_data['Compacidade'], label=pasta, alpha=0.7, color=cor)

    plt.title('Gráfico de Dispersão: Área vs Compacidade')
    plt.xlabel('Área')
    plt.ylabel('Compacidade')
    plt.ylim(0, 1)
    plt.legend()
    plt.grid(True)
    plt.show()

#Interface Grafica--------------------------    

window = tk.Tk()
images_list = tk.Listbox(window)
load_images()
Grafico = tk.Button(window, text="Grafico de dispersão", command=grafico)
images_list.bind("<<ListboxSelect>>", load_image)
label = tk.Label(window)
segmented_label = tk.Label(window)
images_list.grid(row=0,column=0)
Grafico.grid(row=1,column=0)
label.grid(row=0,column=1)
segmented_label.grid(row=0,column=2)
window.mainloop()