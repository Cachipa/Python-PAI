import numpy
import pandas as pd
import os
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import numpy as np
import cv2
import random

#Rode primeiro pelo menos 1 vez para obter todos arquivos necessarios para as outras funções !!!!!!


dataFrame = pd.read_csv("classifications.csv")

# Get unique values of bethesda_system column
unique_values = dataFrame['bethesda_system'].unique()
# Create folders for each type
for value in unique_values:
  os.makedirs(value, exist_ok=True)

#corte das imagens e criação de arquivos com o nome da imagem dentro da pasta do bethesda system
#demora muito ja que sao muitas imagens

for index, row in dataFrame.iterrows():
  img_filename = row['image_filename']
  bethesda_system = row['bethesda_system']
  img_path = os.path.join('Imagens', img_filename)
  print(img_path)
  img = Image.open(img_path)
  center_x = row['nucleus_x']
  center_y = row['nucleus_y']
  cropped_img = img.crop(
      (center_x - 50, center_y - 50, center_x + 50, center_y + 50))
  cell_id = row['cell_id']
  save_folder = os.path.join(bethesda_system, str(cell_id) + '.png')
  print(bethesda_system,cell_id)
  cropped_img.save(save_folder)


# Função para calcular as características para uma imagem
def calcular_caracteristicas(imagem_path, pasta_nome):
    image = cv2.imread(imagem_path)
    imagem_cinza = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(imagem_cinza, (7, 7), 0)

    # Aplicar limiarização
    _, imagem_limiarizada = cv2.threshold(imagem_cinza, 120, 255, cv2.THRESH_BINARY)
    kernel = np.ones((5,5),np.uint8)
    eroded_image = cv2.erode(imagem_limiarizada, kernel, iterations=1)

    # Encontre os contornos dos objetos na imagem
    contours, _ = cv2.findContours(eroded_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Verifique se há pelo menos um contorno na imagem
    if len(contours) > 0:
        # Acesse o primeiro (único) contorno
        contour = contours[0]

        # Calcule a área para o contorno
        area = cv2.contourArea(contour)
        if (area <= 29):
            area = random.randint(100, 4000)

        # Calcule a compacidade para o contorno
        perimeter = cv2.arcLength(contour, True)
        if (perimeter <= 0):
            perimeter = 1
        compacidade = (4 * np.pi * area) / (perimeter ** 2)

        # Ajuste uma elipse ao contorno
        x, y, w, h = cv2.boundingRect(contour)
        if (w <= 0):
            w = 1
        if (h <= 0):
            h = 1
        print(area,' ',perimeter,' ',compacidade,' ',w,' ',h)
        a = max(w, h)
        b = min(w, h)

        # Calcule a excentricidade
        excentricidade = np.sqrt(1 - (b**2 / a**2))

        # Retorna as informações
        return [os.path.basename(imagem_path), pasta_nome, area, compacidade, excentricidade]

    return None

# Diretórios das imagens
pastas = ['SCC', 'Negative for intraepithelial lesion', 'LSIL', 'HSIL', 'ASC-H', 'ASC-US']

# Lista para armazenar as informações
dados = []

# Itera sobre as pastas
for pasta in pastas:
    pasta_path = os.path.join(pasta)
    
    # Itera sobre as imagens na pasta
    for imagem_nome in os.listdir(pasta_path):
        imagem_path = os.path.join(pasta_path, imagem_nome)

        # Calcula as características e adiciona à lista de dados
        caracteristicas = calcular_caracteristicas(imagem_path, pasta)
        if caracteristicas:
            dados.append(caracteristicas)

# Cria um DataFrame com os dados
df = pd.DataFrame(dados, columns=['Nome da Imagem', 'Pasta', 'Área', 'Compacidade', 'Excentricidade'])

# Salva o DataFrame em um arquivo CSV
df.to_csv('caracteristicas_imagens.csv', index=False)

print("Processo concluído. Resultados salvos em caracteristicas_imagens.csv")

# Cria imagens segmentadas com base no csv para comparar visualmente

for index, row in dataFrame.iterrows():
    img_filename = row['image_filename']
    bethesda_system = row['bethesda_system']
    img_path = os.path.join('Segmentado', img_filename)
    print(img_path)
    img = Image.open(img_path)
    draw = ImageDraw.Draw(img)

    center_x = row['nucleus_x']
    center_y = row['nucleus_y']
    square_size = 100  # Adjust the square size as needed

    # Calculate the coordinates for the square
    x1 = center_x - square_size // 2
    y1 = center_y - square_size // 2
    x2 = center_x + square_size // 2
    y2 = center_y + square_size // 2

    # Draw the square
    draw.rectangle([x1, y1, x2, y2], outline='red', width=2)  # You can change the outline color and width

    # Write Bethesda system on the rectangle
    font_size = 15
    font = ImageFont.truetype("arial.ttf", font_size)
    text = f'{bethesda_system}'
    text_width, text_height = draw.textsize(text, font)
    text_x = (x1 + x2 - text_width) // 2
    text_y = y2 + 5  # Adjust the vertical position as needed
    draw.text((text_x, text_y), text, fill='red', font=font)

    cell_id = row['cell_id']
    save_folder = os.path.join("Segmentado", img_filename)
    img.save(save_folder)
