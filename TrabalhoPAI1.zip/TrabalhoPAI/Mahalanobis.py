import numpy
import pandas as pd
import os
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import numpy as np
import cv2
import random
import cv2
import os
import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, pair_confusion_matrix
import seaborn as sns
from sklearn.preprocessing import LabelEncoder


df = pd.read_csv('caracteristicas_imagens.csv')

# Mahalanobis
def mahalanobis_distance(X, mean, cov_inv):
    diff = X - mean
    md = np.sum(np.dot(diff, cov_inv) * diff, axis=1)
    return np.sqrt(md)


# Separe os dados em conjuntos de treino e teste
df['Classe'] = LabelEncoder().fit_transform(df['Pasta'])
X_train, X_test, y_train, y_test = train_test_split(
    df[['Área', 'Compacidade', 'Excentricidade']], df['Classe'], test_size=0.2, random_state=50)

print(X_train, X_test, y_train, y_test)

# Calculate mean and inverse covariance matrix for Mahalanobis distance
mean_vector = X_train.mean(axis=0).values
print(mean_vector)
cov_matrix = np.cov(X_train, rowvar=False)
cov_inv = np.linalg.inv(cov_matrix)

# Classe binária (Negative for intraepithelial lesion X demais)
y_pred_binary = mahalanobis_distance(X_test.values, mean_vector, cov_inv)
median_threshold = np.median(y_pred_binary)
accuracy_binary = accuracy_score(y_test.isin([1]), y_pred_binary > median_threshold)
conf_matrix_binary = confusion_matrix(y_test.isin([1]), y_pred_binary > median_threshold)

# Classe com as 6 classes
y_pred_multi = mahalanobis_distance(X_test.values, mean_vector, cov_inv)
accuracy_multi = accuracy_score(y_test, y_pred_multi > np.median(y_pred_multi))
conf_matrix_multi = confusion_matrix(y_test, y_pred_multi > np.median(y_pred_multi))

# Resultados
print("Mahalanobis Binary Accuracy:", accuracy_binary)
print("Confusion Matrix (Binary):")
print(conf_matrix_binary)

plt.figure(figsize=(10, 10))
sns.heatmap(conf_matrix_binary, annot=True, cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.savefig('BinaryMahalanobis.png')

print("\nMahalanobis Multi-Class Accuracy:", accuracy_multi)
print("Confusion Matrix (Multi-Class):")
print(conf_matrix_multi)

plt.figure(figsize=(10, 10))
sns.heatmap(conf_matrix_multi, annot=True, cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.title('Confusion Matrix')
plt.savefig('MultiMahalanobis.png')