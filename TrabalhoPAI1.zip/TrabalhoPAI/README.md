Trabalho Prático 
 
Segmentação e reconhecimento de células em exames de Papanicolau

Daniel Soares França / Matricula: 700059
Bruno Fonseca Pietra / Matricula: 838317 

N1=0
N2=0, Resnet50

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
Deve ter duas pastas chamadas "Imagens" e "Segmentado" com todas as imagens dentro antes de rodar.
Todos codigos devem estar na mesma pasta com o classifications.csv
Rodar Run.py primeiro para gerar todos arquivos necessarios para as outras
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Run.py / Recorte de imagens + Gera csv com caracteristicas dos nucleos + Segmentação das imagens originais com dados csv para comparar

Main.py / Interface Grafica + Grafico de Dispersão

Mahalanobis.py /  classificadores  de  Mahalanobis

Redes.py / redes convolucionais